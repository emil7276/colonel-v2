# Colonel Fried Chicken POS v2

Fitur: login Admin/Kasir, POS touchscreen, master menu tambah/edit/hapus/nonaktif, identitas usaha, logo teks/emoji, transaksi tunai/non-tunai, laporan periode, produk terlaris, penyimpanan lokal.

Akun awal: admin / 1234 dan kasir / 1234. Ganti password sebelum operasional.
